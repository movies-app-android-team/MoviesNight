package com.example.moviesnight.`interface`

fun interface ErrorCallback {
    fun onError(throwable: Throwable)
}